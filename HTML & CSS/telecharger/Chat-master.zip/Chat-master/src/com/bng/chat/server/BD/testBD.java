package com.bng.chat.server.BD;

public class testBD {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println(Utils.listeContact("bng"));
		System.out.println(Utils.listeContact("sine"));
		
		
	}

}
