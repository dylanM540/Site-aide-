package com.bng.chat.client.vue;

import java.io.File;
import java.io.IOException;

import com.bng.chat.client.Model.ModelConnexion;

public class Init {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) {
		System.out.println(new File("").getAbsolutePath()+"/images/16x16");

	}

}
