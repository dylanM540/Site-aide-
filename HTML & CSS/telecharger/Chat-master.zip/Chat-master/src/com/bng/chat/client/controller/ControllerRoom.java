package com.bng.chat.client.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.bng.chat.client.Model.ModelRoom;
import com.bng.chat.client.vue.VueChat;

public class ControllerRoom implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	
}
