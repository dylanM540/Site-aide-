# * ** BNG's Chat application ** * 
